package devoirmachine;

class DevoirMachine {

    /**
     * Parcourt un tableau pour trouver l'indice de son plus petit élément
     *
     * @param tab tableau d'entiers
     * @return p l'indice de l'élément le plus petit du tableau
     */
    static int fonction1(int[] tab) {
        int p = 0;
        for (int i = 1; i < tab.length; i++) {
            if (tab[i] < tab[p]) {
                p = i;
            }
        }
        return p;
    }

    /**
     * Suite de Fibonacci.
     *
     * @param n indice du terme à calculer
     * @return valeur de la suite de Fibonacci à cet indice
     */
    static int fibo(int n) {
        if (n > 1) {
            n = fibo(n - 1) + fibo(n - 2);
        }
        return n;
    }

    /**
     * Précise si deux tableaux sont égaux, c'est-à-dire sont de même taille, et
     * contiennent les mêmes valeurs, dans le même ordre.
     *
     * @param tab1 premier tableau
     * @param tab2 second tableau
     * @return vrai si les deux tableaux sont égaux
     */
    static boolean tableauxEgaux(int[] tab1, int[] tab2) {
        boolean égal = false;
        int taille1 = tab1.length - 1;
        int taille2 = tab2.length - 1;
        for (int i = 0; i <= taille1; i++) {
            for (int j = 0; j <= taille2; j++) {
                j = i;
                if (tab1[i] == tab2[j]) {
                    égal = true;
                } 
            }
        }
        return égal;
    }
    
    /**
     * Fonction qui compare chaque élément de deux chaînes
     * de caractères de taille égale pour vérifier combien de leur,
     * caractères sont identiques au même indice
     * 
     * @param str1
     * @param str2
     * @return i compteur de caractères identiques entre les deux chaînes
     */
    static int fonction2(String str1, String str2) {
        int i = 0;
        if (str1 != null && str2 != null && str1.length() > 0 && str2.length() > 0) {
            int j = str1.length() - 1;
            int k = str2.length() - 1;
            boolean egalite = true;
            while (j >= 0 && k >= 0 && egalite) {
                if (str1.charAt(j) == str2.charAt(k)) {
                    i++;
                    j--;
                    k--;
                } 
                else {
                    egalite = false;
                }
            }
        }
        return i;
    }

    /**
     * Opère une transposition sur un tableau à deux dimensions carré.
     *
     * @param tab le tableau à modifier
     */
    static void transposer(int[][] tab) {
        int[] temp;
        for (int i = 1; i <= tab.length - 2; i++) {
                temp = tab[i];
                tab[i] = tab[tab.length-i];
                tab[tab.length-i] = temp;
        }
        // ...
    }

    /**
     * Vérifie s'il existe une ligne et une colonne ayant les mêmes contenus,
     * dans un tableau à deux dimensions carré.
     *
     * @param tab le tableau à analyser
     * @return vrai ssi il existe une ligne et une colonne avec le même contenu
     */
    static boolean ligneEgaleColonne(int[][] tab) {
        boolean égal = false;
        for (int i = 0; i <= tab.length - 1; i++) {
            for (int j = tab.length - 1; j >= 0; j--) {
                if (tab[i] == tab[j]) {
                    égal = true;
                }
            }
        }
        return égal;
    }
}
