package devoirmachine;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class DevoirMachineTest {

    @Test
    public void testFonction1() {
        int[] tabTest = {4, 2, 3, 0};
        assertEquals(3, DevoirMachine.fonction1(tabTest));
        int[] tabTest2 = {1, -10, 2, 7};
        assertEquals(1, DevoirMachine.fonction1(tabTest2));
    }

    @Test
    public void testFibo() {
        assertEquals(0, DevoirMachine.fibo(0));
        assertEquals(1, DevoirMachine.fibo(1));
        assertEquals(1, DevoirMachine.fibo(2));
        assertEquals(2, DevoirMachine.fibo(3));
        assertEquals(3, DevoirMachine.fibo(4));
        assertEquals(5, DevoirMachine.fibo(5));
        assertEquals(8, DevoirMachine.fibo(6));
        assertEquals(13, DevoirMachine.fibo(7));
        assertEquals(21, DevoirMachine.fibo(8));
    }

    @Test
    public void testTableauxEgaux() {
        // tableaux égaux quelconques
        int[] tab1 = {19, -6, 8, 0, 3};
        int[] tab2 = {19, -6, 8, 0, 3};
        assertTrue(DevoirMachine.tableauxEgaux(tab1, tab2));
        // tableaux de même taille mais différents
        int[] tab3 = {19, -6, 8, 0, 3};
        int[] tab4 = {19, -6, 4, 0, 3};
        assertFalse(DevoirMachine.tableauxEgaux(tab3, tab4));
        // tableaux de taille différente
        int[] tab5 = {19, -6, 8, 0, 3};
        int[] tab6 = {19, -6, 8, 0};
        assertFalse(DevoirMachine.tableauxEgaux(tab5, tab6));
        // tableaux à un seul élément et égaux
        int[] tab7 = {-5};
        int[] tab8 = {-5};
        assertTrue(DevoirMachine.tableauxEgaux(tab7, tab8));
        // tableaux vides : égaux
        int[] tab9 = {};
        int[] tab10 = {};
        assertTrue(DevoirMachine.tableauxEgaux(tab9, tab10));
    }

    @Test
    public void testFonction2() {
        /*
        // Problème d'initialisation des chaînes pour le test :'(
        String str1 = {'c', 'd', 'e'};
        String str2 = {'c', 'd', 'e'};
        assertEquals(3, DevoirMachine.fonction2(str1, str2));
        String str3 = {'a', 'd', 'e', 'r'};
        String str4 = {'c', 'd', 'e', 'x'};
        assertEquals(2, DevoirMachine.fonction2(str3, str4));
        */
    }
    
    @Test
    public void testTransposer() {
        // cas général, tableau 3x3
        int[][] tab1o = {{3, -1, 2}, {4, 7, -3}, {-9, 6, 5}};
        DevoirMachine.transposer(tab1o);
        int[][] tab1s = {{3, 4, -9}, {-1, 7, 6}, {2, -3, 5}};
        assertArrayEquals(tab1s, tab1o);
        // cas général, tableau 2x2
        int[][] tab2o = {{3, -1}, {4, 7}};
        DevoirMachine.transposer(tab2o);
        int[][] tab2s = {{3, 4}, {-1, 7}};
        assertArrayEquals(tab2s, tab2o);
        // tableau 1x1
        int[][] tab3o = {{3}};
        DevoirMachine.transposer(tab3o);
        int[][] tab3s = {{3}};
        assertArrayEquals(tab3s, tab3o);
    }
    
    @Test
    public void testLigneEgaleColonne() {
        int[][] tab1 = {{1, 2}, {2, 3}};
        assertTrue(DevoirMachine.ligneEgaleColonne(tab1));
        int[][] tab2 = {{1, 3}, {2, 3}};
        assertFalse(DevoirMachine.ligneEgaleColonne(tab2));
        int[][] tab3 = {{-5, 9, -1}, {-1, 7, 7}, {4, 3, 7}};
        assertTrue(DevoirMachine.ligneEgaleColonne(tab3));
        int[][] tab4 = {{-5, 9, -1}, {-1, 7, 7}, {-1, 7, 7}};
        assertTrue(DevoirMachine.ligneEgaleColonne(tab4));
        int[][] tab5 = {{-5, 9, -2}, {-1, 7, 7}, {-1, 7, 7}};
        assertFalse(DevoirMachine.ligneEgaleColonne(tab5));
        int[][] tab6 = {{1}};
        assertTrue(DevoirMachine.ligneEgaleColonne(tab6));
    }
}
